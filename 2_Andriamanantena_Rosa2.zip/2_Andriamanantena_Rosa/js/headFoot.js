
var prixTout = 0;
var nombreAchat = 0;
var tableauAchat = [];
// localStorage.setItem("panier" , JSON.stringify(tableauAchat));


document.addEventListener("DOMContentLoaded",function(){
        var titre_list = document.querySelectorAll(".title-list");

        titre_list.forEach(titre => {
            titre.addEventListener("click",function(){
                var ul = this.parentNode;
                var lis = ul.querySelectorAll(".list");
                lis.forEach(li => {
                    if(li.style.display == "none"){
                        li.style.display = "block";
                    }else{
                        li.style.display = "none";
                    }
                })          
            })
        })

        AjoutPanier();

        //effacer tous les achats
        var effacerTout = document.querySelector(".effacerTout");
        effacerTout.addEventListener("click",function(){

            if(nombreAchat != 0){
                const res = window.confirm("Voulez vraiment tout effacer ?" );
    
                if(res){
    
                    localStorage.setItem("panier" , JSON.stringify(tableauAchat));
                    tableauAchat = JSON.parse(localStorage.getItem("panier"));
                    tableauAchat = [];
                    localStorage.setItem("panier" , JSON.stringify(tableauAchat));
                    
                    AjoutPanier();
                }

            }

        });

        let fermer = document.querySelector("#fermer");
        let panier_box = document.querySelector(".panier-box");
        let monPanier = document.querySelector("#monPanier");
        let monMenu = document.querySelector("#monMenu");
        let menuBox = document.querySelector(".menu-box");
        let fermerMenu = document.querySelector("#fermerMenu");
        let acheter = document.querySelector(".acheter");
        let input_box = document.querySelector(".input-box");
        let action_panier_box = document.querySelector(".action-panier-box");
        let achats = document.querySelector(".achats");


        // quand on clique "aller aux achats" les inputs correspondant s'affichent
        acheter.addEventListener("click" , function(){
            action_panier_box.classList.toggle("height");
            input_box.classList.toggle("flex");
            achats.classList.toggle("padding");
        })

        //toggle de la visiblité du panier-box
        monMenu.addEventListener("click" , function(){
            menuBox.classList.toggle("visible");
            panier_box.classList.remove("visible");
            
        })

        //fermeture du menu qui contient les navigations
        fermerMenu.addEventListener("click" , function(){
            menuBox.classList.remove("visible");
        })

        // fermeture du panier-box
        fermer.addEventListener("click" , function(){
            panier_box.classList.remove("visible");
        })
        
        monPanier.addEventListener("click" , function(){
            panier_box.classList.toggle("visible");
            menuBox.classList.remove("visible");

            
        })

});


function compterAchat(){
    var containerNbrAchat = document.querySelector("#nbrAchat");
    var containerNbrLivre = document.querySelector("#total-elment");
    let prixTotalTout = document.querySelector("#prixTotalTout");

    containerNbrAchat.innerText = nombreAchat;
    containerNbrLivre.innerText = nombreAchat + " livres";
    prixTotalTout.innerText = prixTout + " ar";

}

function AjoutPanier(){
    
    let panierData = localStorage.getItem("panier");
    tableauAchat = panierData ? JSON.parse(panierData) : [];
    
    var achats = document.querySelector(".achats");

    while(achats.firstChild){
        achats.removeChild(achats.firstChild);
    }
    
    nombreAchat = 0;
    prixTout = 0;

    if (tableauAchat.length !== 0) {
        tableauAchat.forEach((data)=>{
            
            nombreAchat += data.nombre;
            prixTout += data.prixTotal;
            const achat = document.createElement("div");
            achat.classList.add("achat");
            achat.innerHTML = " <div class='achat-image-container'>"+
                                "     <img src='"+data.image_src+"' alt=''>"+
                                "</div>"+
                                "<div class='achat-info'>"+
                                
                                "     <span class='achat-titre'>"+
                                                data.titre+
                                "     </span>"+
                                "     <div class='achat-action'>"+
                                "<span class='prixTotal'>"+ data.prixTotal+ "</span>"+
                                "<input type='number' min='1' class='number' value='"+data.nombre+"'>"+
                                "          <svg class='effacer-achat' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><path d='M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z'/></svg>"+
                                "     </div>"+
                                "</div>";

                                var numberBox = achat.querySelector(".number");
                                var prixTotal = achat.querySelector(".prixTotal");

                                achat.querySelector(".effacer-achat").addEventListener("click" , function(){
                                    nombreAchat -= data.nombre;
                                    prixTout -= data.prixTotal;
                                    
                                    let tableauTmp = tableauAchat.filter(elmt=> elmt.id != data.id)
                                    tableauAchat = tableauTmp;

                                    localStorage.setItem("panier" , JSON.stringify(tableauAchat));

                                    this.closest('.achat').remove();
                                    compterAchat();
                    
                                });

                                numberBox.addEventListener("change" , function(){
                                    var nbr = parseInt(achat.querySelector(".number").value);
                                    
                                    nombreAchat -= data.nombre;
                                    prixTout -= data.prixTotal;

                                    data.nombre = nbr;

                                    data.prixTotal = data.nombre * parseInt(data.prix);
                                    
                                    prixTout += data.prixTotal;
                                    
                                    prixTotal.innerHTML = data.prixTotal;
                                    nombreAchat += nbr;
                                    localStorage.setItem("panier" , JSON.stringify(tableauAchat));

                                    compterAchat();

                                })

                                achats.appendChild(achat);
                                                        
        })
    }

            compterAchat();
  
}