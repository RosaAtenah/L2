var nombreAchat = 0;
var prixTout = 0;
var tableauAchat = [];
var tableauLivre = [];
// localStorage.setItem("panier" , JSON.stringify(tableauAchat));

/*
    fonction qui change l'affichage du prix total et le nombre total des livres achetées
*/
function compterAchat(){
    var containerNbrAchat = document.querySelector("#nbrAchat");
    var containerNbrLivre = document.querySelector("#total-elment");
    let prixTotalTout = document.querySelector("#prixTotalTout");

    containerNbrAchat.innerText = nombreAchat;
    containerNbrLivre.innerText = nombreAchat + " livres";
    prixTotalTout.innerText = prixTout + " ar";

}

/*
    fonction qui ajoute les achats dans l'affichage du panier_box
*/
function AjoutPanier(){
    
    let panierData = localStorage.getItem("panier");
    tableauAchat = panierData ? JSON.parse(panierData) : [];
    
    var achats = document.querySelector(".achats");

    //effacer le contenu de "achats"
    while(achats.firstChild){
        achats.removeChild(achats.firstChild);
    }
    
    nombreAchat = 0;
    prixTout = 0;
    
    //affichage des données dans le achats
    if (tableauAchat.length !== 0) {
        tableauAchat.forEach((data)=>{
            
            nombreAchat += data.nombre;
            prixTout += data.prixTotal;

            const achat = document.createElement("div");
            achat.classList.add("achat");
            achat.innerHTML = " <div class='achat-image-container'>"+
                                "     <img src='"+data.image_src+"' alt=''>"+
                                "</div>"+
                                "<div class='achat-info'>"+
                                
                                "     <span class='achat-titre'>"+
                                                data.titre+
                                "     </span>"+
                                "     <div class='achat-action'>"+
                                "<span class='prixTotal'>"+ data.prixTotal+ "</span>"+
                                "<input type='number' min='1' class='number' value='"+data.nombre+"'>"+
                                "          <svg class='effacer-achat' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><path d='M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z'/></svg>"+
                                "     </div>"+
                                "</div>";

                                var numberBox = achat.querySelector(".number");
                                var prixTotal = achat.querySelector(".prixTotal");

                                //dans le cas ou on efface un achat , on l'efface dans le tableau des achats
                                achat.querySelector(".effacer-achat").addEventListener("click" , function(){
                                    nombreAchat -= data.nombre;
                                    
                                    let tableauTmp = tableauAchat.filter(elmt=> elmt.id != data.id)
                                    tableauAchat = tableauTmp;

                                    localStorage.setItem("panier" , JSON.stringify(tableauAchat));

                                    this.closest('.achat').remove();
                                    compterAchat();
                    
                                });
                                
                                /*
                                    dans le cas ou le nombre de chaque livre change , 
                                    on change son prix total
                                */
                                numberBox.addEventListener("change" , function(){

                                    var nbr = parseInt(achat.querySelector(".number").value);
                                    
                                    nombreAchat -= data.nombre;
                                    data.nombre = nbr;
                                    prixTout -= data.prixTotal;

                                    data.prixTotal = data.nombre * parseInt(data.prix);
                                    
                                    prixTout += data.prixTotal;
                                    
                                    prixTotal.innerHTML = data.prixTotal;
                                    nombreAchat += nbr;
                                    localStorage.setItem("panier" , JSON.stringify(tableauAchat));

                                    compterAchat();

                                })

                                achats.appendChild(achat);
                                                        
        })
    }

            compterAchat();
}

/*
    fonction qui ajoute les achats dans le tableau des achats
*/
function avantAjoutPanier(donne){
    
        localStorage.setItem("panier" , JSON.stringify(tableauAchat));


        let panierData = localStorage.getItem("panier");
        tableauAchat = panierData ? JSON.parse(panierData) : [];
        

        var tableauTmp =  {
            "id":donne.id,
            "image_src":donne.image_src,
            "titre":donne.titre,
            "prix": donne.prix,
            "prixTotal":parseInt(donne.prix),
            "nombre" : 1,
        };

        let bool = false;
        console.log(tableauAchat)


            tableauAchat.forEach((data)=>{
                if(data.id === tableauTmp.id){
                    data.nombre ++;
                    data.prixTotal = parseInt( data.prix )* data.nombre;
                    bool = true;
                }
            })
      
        
        if(!bool){
            
            tableauAchat.push(tableauTmp);
        }

        localStorage.setItem("panier" , JSON.stringify(tableauAchat));
        
        AjoutPanier();

}

/*
    fonction qui affiche les livres selon le filtre
*/
function affichageLivre(filtre){
    const cases = document.querySelector(".cases");


    tableauLivre.forEach(data => {
        const {id , image_src,titre , prix , description , auteur} = data;
    
    
        if(titre.includes(filtre)){
    
            const case_ = document.createElement("div");
            image_case = document.createElement("div");
            const description_case = document.createElement("div");
           
            image_case.classList.add("img-case");
            description_case.classList.add("description-case");
            case_.classList.add("case");
    
            case_.setAttribute("data-aos" , "fade-in");
            image_case.innerHTML = "<img src= '" + image_src + "' alt=''>";
            
            description_case.innerHTML = "<div class='more-about-case'>"+
            // "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><path d='M253.3 35.1c6.1-11.8 1.5-26.3-10.2-32.4s-26.3-1.5-32.4 10.2L117.6 192H32c-17.7 0-32 14.3-32 32s14.3 32 32 32L83.9 463.5C91 492 116.6 512 146 512H430c29.4 0 55-20 62.1-48.5L544 256c17.7 0 32-14.3 32-32s-14.3-32-32-32H458.4L365.3 12.9C359.2 1.2 344.7-3.4 332.9 2.7s-16.3 20.6-10.2 32.4L404.3 192H171.7L253.3 35.1zM192 304v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16s16 7.2 16 16zm96-16c8.8 0 16 7.2 16 16v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16zm128 16v96c0 8.8-7.2 16-16 16s-16-7.2-16-16V304c0-8.8 7.2-16 16-16s16 7.2 16 16z'/></svg>"+
            "<svg class='panier' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><path d='M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z'/></svg>"+
            "<svg class='lire-plus' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><path d='M528.3 46.5H388.5c-48.1 0-89.9 33.3-100.4 80.3-10.6-47-52.3-80.3-100.4-80.3H48c-26.5 0-48 21.5-48 48v245.8c0 26.5 21.5 48 48 48h89.7c102.2 0 132.7 24.4 147.3 75 .7 2.8 5.2 2.8 6 0 14.7-50.6 45.2-75 147.3-75H528c26.5 0 48-21.5 48-48V94.6c0-26.4-21.3-47.9-47.7-48.1zM242 311.9c0 1.9-1.5 3.5-3.5 3.5H78.2c-1.9 0-3.5-1.5-3.5-3.5V289c0-1.9 1.5-3.5 3.5-3.5h160.4c1.9 0 3.5 1.5 3.5 3.5v22.9zm0-60.9c0 1.9-1.5 3.5-3.5 3.5H78.2c-1.9 0-3.5-1.5-3.5-3.5v-22.9c0-1.9 1.5-3.5 3.5-3.5h160.4c1.9 0 3.5 1.5 3.5 3.5V251zm0-60.9c0 1.9-1.5 3.5-3.5 3.5H78.2c-1.9 0-3.5-1.5-3.5-3.5v-22.9c0-1.9 1.5-3.5 3.5-3.5h160.4c1.9 0 3.5 1.5 3.5 3.5v22.9zm259.3 121.7c0 1.9-1.5 3.5-3.5 3.5H337.5c-1.9 0-3.5-1.5-3.5-3.5v-22.9c0-1.9 1.5-3.5 3.5-3.5h160.4c1.9 0 3.5 1.5 3.5 3.5v22.9zm0-60.9c0 1.9-1.5 3.5-3.5 3.5H337.5c-1.9 0-3.5-1.5-3.5-3.5V228c0-1.9 1.5-3.5 3.5-3.5h160.4c1.9 0 3.5 1.5 3.5 3.5v22.9zm0-60.9c0 1.9-1.5 3.5-3.5 3.5H337.5c-1.9 0-3.5-1.5-3.5-3.5v-22.8c0-1.9 1.5-3.5 3.5-3.5h160.4c1.9 0 3.5 1.5 3.5 3.5V190z'/></svg>"+
            "</div>"+
            "<span class='title-case'>"+
                titre+
            "</span>"+
            "<span class='case-category'>"+
                prix+
            "</span>"+
            "<span class='desc-livre'>"+
            description+
            "    <p>Auteur : "+auteur+"</p>"+
            "</span>"+
            "</div>";
    
            case_.appendChild(image_case);
            case_.appendChild(description_case);
    
            cases.appendChild(case_);
    
            description_case.querySelector(".panier").addEventListener("click" , function(){
                avantAjoutPanier({id , image_src,titre , prix});
            });
    
            description_case.querySelector(".lire-plus").addEventListener("click",function(){
                //lirePlus(image_src,titre,prix,description);
                var elements = document.querySelectorAll(".case");
    
                elements.forEach(element => {
                    element.style.display = "none";
                });
    
                var caseClique = document.querySelector(".caseClique");
                var image = caseClique.querySelector("img");    
                var titre_case = caseClique.querySelector(".title-case");
                var prixLivre = caseClique.querySelector("#prixLivre");
                var descp  = caseClique.querySelector("#descp");        
                var auteurLivre = caseClique.querySelector("#auteur");
            
                caseClique.querySelector(".panier").addEventListener("click",function(){
                    avantAjoutPanier({id , image_src,titre , prix});    
                });
    
    
    
                image.src = image_src;
                titre_case.innerHTML = titre;
                prixLivre.innerHTML = prix;
                descp.innerHTML = description;
                auteurLivre.innerHTML = auteur;
    
                caseClique.style.display = "flex";
            });
        }

    })

}



document.addEventListener("DOMContentLoaded" , function(){
   
        //prendre les donnes dans le json 
        fetch('../json/livre.json')
        .then(response => response.json())
        .then(datas => {
            datas.forEach(data => {

                tableauLivre.push(data);
            });
            
            affichageLivre("");
        });

    
        
       AjoutPanier();

        var lireMoins = document.querySelector("#lire-moins");
        let recherche = document.querySelector("#recherche");
        let rechercheBox = document.querySelector(".rechercheBox");
        let main = document.querySelector("main");
        let footer = document.querySelector("footer");
        let effacer = rechercheBox.querySelector("svg");
        let rechercheInput = rechercheBox.querySelector("input");
        const cases = document.querySelector(".cases");


        //effacer le contenu du input quand la croix est cliqué
        effacer.addEventListener("click" , function(){
            rechercheInput.value = "";
        })

        //quand recherche est cliquée afficher la page de recherche
        recherche.addEventListener("click" , function(){
            rechercheBox.classList.toggle("flex");
            main.classList.toggle("flex");
            footer.classList.toggle("flex");
            document.addEventListener("keydown" , touchEntrerClique);

        })

        //la fonction appelé quand la touche entrée est cliqué pour faire la recherche
        function touchEntrerClique(event){
            

            if(event.key === 'Enter'){
               
                while(cases.firstChild){
                    cases.removeChild(cases.firstChild);
                }
    
                //afficher les livres selon la valeur de l'input
                affichageLivre(rechercheInput.value);
                rechercheBox.classList.remove("flex");
                main.classList.remove("flex");
                footer.classList.remove("flex");
                rechercheInput.value = "";
                
            }


        }


       

        //quand lireMoins est cliqué la description sur le livre ne s'affiche plus
        lireMoins.addEventListener("click", function(){
            var elements = document.querySelectorAll(".case");
            
            elements.forEach(element => {
                element.style.display = "block";
            });
            
            var caseClique = document.querySelector(".caseClique");
            caseClique.style.display = "none";
            
            
        });



        
        



})

