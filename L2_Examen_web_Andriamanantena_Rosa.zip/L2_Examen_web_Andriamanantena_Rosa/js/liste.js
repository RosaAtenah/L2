var tableauLivre = [];

async function AjoutTableauLivre() {
    try {
        const response = await fetch("./json/livre.json");
        const datas = await response.json();
        if (localStorage.getItem("livre")) {
            tableauLivre = datas;
            localStorage.setItem("livre", JSON.stringify(tableauLivre));
        }

    } catch (error) {
        console.error("Error fetching data:", error);
    }
}

function AffichageTableau(){

    tableauLivre = JSON.parse(localStorage.getItem("livre"));
    
    let boxLivres = document.querySelector(".boxLivres");

    boxLivres.innerHTML = ''

    console.log(tableauLivre);
    tableauLivre.forEach(datas => {

        const {id ,imageSource ,titre ,auteur, categorie,publication,resume , emplacement , etat , disponibilite , nbrPage , editeur} = datas;
        let boxLivre = document.createElement("div");

        boxLivre.classList.add("boxLivre");

        boxLivre.innerHTML = `
            <div class="imageContainer">
                <img src="${imageSource}" alt="">
            </div>
            <div class="detailLivre">
                <span class="titrelivre"><p>${titre}</p></span>
                <span class="auteurLivre"><p>${auteur}</p></span>
                <span class="categorieLivre"><p>${categorie}</p></span>
                <span class="publication"><p>${publication}</p></span>
                <input type="button" value="supprimer" class="supprimer">
                <a href="#boxDetail">
                     <input type="button" value="Voir detail" class="detail">

                </a>
            </div>
        `;

        boxLivres.appendChild(boxLivre);

        let detail = boxLivre.querySelector(".detail");
        let supprimer = boxLivre.querySelector(".supprimer");

        supprimer.addEventListener("click" , function(){
            tableauLivre = tableauLivre.filter(elmt => elmt.id !== id)
            localStorage.setItem("livre" , JSON.stringify(tableauLivre));
            console.log("ici");
            console.log(tableauLivre);
            boxLivre.remove();
        })

        detail.addEventListener("click" , function(){
            let boxDetail = document.querySelector(".boxDetail");
            while(boxDetail.firstChild){
                boxDetail.removeChild(boxDetail.firstChild)
            }

            boxDetail.innerHTML = `
            <div class="imageContainer">
                <img src="${imageSource}" alt="">
            </div>
            <div class="textDetailBox">

                <p> Titre :  <span> ${titre}</span></p>
                <p> auteur :  <span> ${auteur}</span></p>
                <p> categorie :  <span> ${categorie}</span></p>
                <p> date de publication :  <span> ${publication}</span></p>
                <p> emplacement :  <span> ${emplacement}</span></p>
                <p> etat :  <span> ${etat}</span></p>
                <p> disponibilite :  <span> ${disponibilite}</span></p>
                <p> nbrPage :  <span> ${nbrPage}</span></p>
                <p> editeur :  <span> ${editeur}</span></p>
                <p> resume :  <span> ${resume}</span></p>
            </div>
            `;
        })


        
    })
}

function getRadioValue(name) {
    let radios = document.getElementsByName(name);
    for (let i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            return radios[i].value;
        }
    }

    return "";
}


function AjoutLivre(){
 
    let categorie = document.querySelector("#categorie");
    let submit = document.querySelector("#submit")

 
    submit.addEventListener("click" , function(){
        let imageSource = document.querySelector("#imageSource").value;
        let  titre = document.querySelector("#titre").value;
        let auteur = document.querySelector("#auteur").value
        let date = document.querySelector("#date").value
        let resume = document.querySelector("#resume").value
        let emplacment = document.querySelector("#emplacment").value
        let etat = document.querySelector("#etat").value
        let nbrPage = document.querySelector("#nbrPage").value
        let editeur = document.querySelector("#editeur").value
        let disponibilite = getRadioValue("disponibilite");
        let  categorieValue = categorie.value;

        // console.log(categorieValue);

        

        let tableauLivreTmp = 
        {
            "id":tableauLivre.length + 1 ,
            "imageSource":imageSource,
            "titre":titre,
            "auteur":auteur,
            "categorie":categorieValue,
            "date":date,
            "emplacment":emplacment,
            "etat":etat,
            "nbrPage":nbrPage,
            "editeur":editeur,
            "disponibilite":disponibilite,
            "resume":resume
        }

        tableauLivre.push(tableauLivreTmp);
        
        //localStorage.setItem("nouveauLivre" , JSON.stringify(tableauLivreNouveau));
      
        // tableauLivreNouveau = JSON.parse(localStorage.getItem("nouveauLivre"))

        // console.log(tableauLivreNouveau);
        //tableauLivre = tableauLivre.concat(tableauLivreTmp)
        localStorage.setItem("livre" , JSON.stringify(tableauLivre));

        AffichageTableau();

    })


}




document.addEventListener("DOMContentLoaded" ,async function(){
    
    await AjoutTableauLivre();

    let data = JSON.parse(localStorage.getItem("livre"));
    tableauLivreNouveau = data ? data : tableauLivre;
    // tableauLivre = tableauLivre.concat(tableauLivreNouveau)
    // localStorage.setItem("livre" , JSON.stringify(tableauLivre));

    AffichageTableau();
    AjoutLivre()


    
})