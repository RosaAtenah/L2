let tableauLivre = [];
var tableauCategorie = [];

async function AjoutTableauLivre() {
  try {
    const response = await fetch("./json/livre.json");
    const datas = await response.json();

    // Ajouter les livres du JSON seulement si localStorage est vide
    if (!localStorage.getItem("livre")) {
      tableauLivre = datas;
      localStorage.setItem("livre", JSON.stringify(tableauLivre));
    }
  } catch (error) {
    console.error("Error fetching data:", error);
  }
}

function AffichageTableau() {
  let boxLivres = document.querySelector(".boxLivres");
  boxLivres.innerHTML = "";

  tableauLivre.forEach((datas) => {
    const {
      id,
      imageSource,
      titre,
      auteur,
      genre,
      publication,
      resume,
      emplacement,
      etat,
      disponibilite,
      nbrPage,
      categorie,
      editeur,
    } = datas;

    let boxLivre = document.createElement("div");

    boxLivre.classList.add("boxLivre");

    boxLivre.innerHTML = `
                    <div class="imageContainer">
                        <img src="${imageSource}" alt="">
                    </div>
                    <div class="detailLivre">
                        <span class="titreLivre"><p>${titre}</p></span>
                        <span class="auteurLivre"><p>${auteur}</p></span>
                        <span class="genre<livre"><p>${genre}</p></span>
                        <span class="publication"><p>${publication}</p></span>
                        <input type="button" value="Supprimer" class="supprimer">
                        <a href="#boxDetail">
                             <input type="button" value="Voir detail" class="detail">

                        </a>
                        <input type="button" value="ajout Categorie" class="ajoutCategorie">
                    </div>
                `;

                let ajoutCategorie = boxLivre.querySelector(".ajoutCategorie");

                ajoutCategorie.addEventListener("click" , function(){
                  
                })
    boxLivres.appendChild(boxLivre);

    let detail = boxLivre.querySelector(".detail");
    let supprimer = boxLivre.querySelector(".supprimer");


    supprimer.addEventListener("click", function () {
      tableauLivre = tableauLivre.filter((elmt) => elmt.id !== id);
      localStorage.setItem("livre", JSON.stringify(tableauLivre));
      boxLivre.remove();
    });

    detail.addEventListener("click", function () {
      let boxDetail = document.querySelector(".boxDetail");
      boxDetail.innerHTML = `
                        <div class="imageContainer">
                            <img src="${imageSource}" alt="">
                        </div>
                        <div class="textDetailBox">
                            <p>Titre : <span>${titre}</span></p>
                            <p>Auteur : <span>${auteur}</span></p>
                            <p>genre : <span>${genre}</span></p>
                            <p>Catégorie : <span>${categorie}</span></p>
                            <p>Date de publication : <span>${publication}</span></p>
                            <p>Emplacement : <span>${emplacement}</span></p>
                            <p>État : <span>${etat}</span></p>
                            <p>Disponibilité : <span>${disponibilite}</span></p>
                            <p>Nombre de pages : <span>${nbrPage}</span></p>
                            <p>Éditeur : <span>${editeur}</span></p>
                            <p>Résumé : <span>${resume}</span></p>
                        </div>
                    `;
    });
  });
}

function getRadioValue(name) {
  let radios = document.getElementsByName(name);
  for (let i = 0; i < radios.length; i++) {
    if (radios[i].checked) {
      return radios[i].value;
    }
  }
  return "";
}

function AjoutLivre() {
  let submit = document.querySelector("#submit");

  submit.addEventListener("click", function () {
    let imageSource = document.querySelector("#imageSource").value;
    let titre = document.querySelector("#titre").value;
    let auteur = document.querySelector("#auteur").value;
    let date = document.querySelector("#date").value;
    let resume = document.querySelector("#resume").value;
    let emplacement = document.querySelector("#emplacement").value;
    let etat = document.querySelector("#etat").value;
    let nbrPage = document.querySelector("#nbrPage").value;
    let editeur = document.querySelector("#editeur").value;
    let disponibilite = getRadioValue("disponibilite");
    let categorie = document.querySelector("#categorie").value;
    let genre = document.querySelector("#genre").value;


    let tableauLivreTmp = {
      id: tableauLivre.length + 1, // Ajout d'un ID unique
      imageSource: imageSource,
      titre: titre,
      auteur: auteur,
      genre: categorie,
      categorie:genre,
      publication: date,
      emplacement: emplacement,
      etat: etat,
      nbrPage: nbrPage,
      editeur: editeur,
      disponibilite: disponibilite,
      resume: resume,
    };

    tableauLivre.push(tableauLivreTmp);
    localStorage.setItem("livre", JSON.stringify(tableauLivre));

    AffichageTableau();
  });
}

async function AjoutTableauCategorie() {
    try {
        const response = await fetch("./json/categorie.json");
        const datas = await response.json();
    
        // Ajouter des du JSON seulement si localStorage est vide
        if (!localStorage.getItem("categorie")) {
          tableauCategorie = datas;
          localStorage.setItem("categorie", JSON.stringify(tableauCategorie));
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
}


function AffichageTableauCategorie(){

    let ul = document.querySelector(".listCategorie");

    ul.innerHTML = "";

    tableauCategorie.forEach((datas,index) => {

        let li = document.createElement("li");

        li.innerHTML = `
             <span>${datas}</span>
            <input type="button" value="modifier" class="modifier">
            <input type="button" value="supprimer" class="supprimer">


        `;


        ul.appendChild(li);

        let modifier = li.querySelector(".modifier");
        modifier.addEventListener("click" , function(){
          li.innerHTML = `
          <input type="text" value="${datas}" class="nouvelleCategorie">
            <input type="button" value="enregistrer" class="enregistrer">
            <input type="button" value="supprimer" class="supprimer">
        `;

        let enregistrer = li.querySelector(".enregistrer");

        enregistrer.addEventListener("click" , function(){
          let nouvelleCategorie = li.querySelector(".nouvelleCategorie").value;
          tableauCategorie[index] = nouvelleCategorie;

          localStorage.setItem("categorie", JSON.stringify(tableauCategorie));
          li.innerHTML = `
          <span>${nouvelleCategorie}</span>
              <input type="button" value="modifier" class="modifier">
              <input type="button" value="supprimer" class="supprimer">

           `;

           categorieSelect();

        })

        let supprimer = li.querySelector(".supprimer");
        supprimer.addEventListener("click", function() {

          console.log("ixi");
            // Supprimer la catégorie du tableau et de localStorage
            tableauCategorie.splice(index, 1);
            localStorage.setItem("categorie", JSON.stringify(tableauCategorie));
            li.remove();
            // Rafraîchir l'affichage du tableau de catégories
            // AffichageTableauCategorie();
            categorieSelect();
        });


        })
    })
}


function AjoutCategorie(){
    let ajout = document.querySelector("#ajout");
    let inputCategorie = document.querySelector("#inputCategorie");
    let categorieValue = "";

    inputCategorie.addEventListener("change" , function(){

        if(inputCategorie.value !== ""){

            categorieValue =  inputCategorie.value;
        }
        inputCategorie.value = "";
    })
    
    console.log(categorieValue);

    ajout.addEventListener("click" , function(){
        tableauCategorie.push(categorieValue);
        localStorage.setItem("categorie", JSON.stringify(tableauCategorie));
        AffichageTableauCategorie();
        categorieSelect();
    })
}

function categorieSelect(){
    let selectCategorie = document.querySelector("#genre");
    selectCategorie.innerHTML = "";

    tableauCategorie.forEach(data => {
        selectCategorie.innerHTML += `<option value="${data}">${data}</option>`;
    })
}

document.addEventListener("DOMContentLoaded", async function () {
  await AjoutTableauLivre();
  await AjoutTableauCategorie();

  let data = JSON.parse(localStorage.getItem("livre"));
  tableauLivre = data ? data : tableauLivre;

   data = JSON.parse(localStorage.getItem("categorie"));
  tableauCategorie = data ? data : tableauCategorie;

  AffichageTableau();
  AffichageTableauCategorie();
  AjoutLivre();
  AjoutCategorie();
    categorieSelect();
});
