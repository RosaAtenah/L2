
// tableau qui contiendra la reponse de json
var tableauOuverture = [];

// fonction qui rempli le tableau ouverture
async function pushOuverture(){
    await fetch('../json/ouverture.json')
    .then(response => response.json())
    .then(datas => {
        datas.forEach(data => {

            tableauOuverture.push(data);
        });
    });
    
}


//fonction qu'on appelle selon le type de l'ouverture séléctionné
function selectOuverture (typeOuverture){
  
    const awards = document.querySelector(".awards");
    tableauOuverture.forEach(data => {


                //declaration des variables
                const {type,nom,etapes} = data;
           
            if(type.includes(typeOuverture.toLowerCase())){  

                const award = document.createElement("div");
                const conteneur = document.createElement("div");
                const h3 = document.createElement("h3");
                const discover = document.createElement("div");

                //attribution des classes
                award.classList.add("award");
                award.setAttribute("data-aos" , "zoom-out-up");

                conteneur.classList.add("conteneur");
                discover.classList.add("discover");

                //insertion du nom dans h3
                h3.innerText = nom;
                let h3_id = nom.replaceAll(" ","_");
                h3_id = h3_id.replaceAll("'","_");
                h3_id = h3_id.replaceAll("é" , "e");

                h3.id = h3_id;

                //insertion du h3 dans conteneur
                conteneur.appendChild(h3);

                //insertion dans discover
                discover.innerHTML = "<p>LIRE LA SUITE</p><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><path d='M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z'/></svg>";

                //insertion des etapes
                etapes.forEach(etape =>{
                    // console.log(etape);
                    const p = document.createElement("p");
                    p.classList.add("date");
                    p.innerText = etape;
                    conteneur.appendChild(p);
                });

                conteneur.appendChild(discover);

                
                award.appendChild(conteneur);
                // awards.removeChild();

               
                awards.appendChild(award);
            }
           

            });

            var discovers = document.querySelectorAll(".discover");

            discovers.forEach(function(discover){
                discover.addEventListener("click",function(){

                    var award = this.parentNode.parentNode;
                    if(award.style.height === "50px"){
                        award.style.height = "auto";
                        discover.innerHTML = "<p>VOIR MOINS</p><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><path d='M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z'/></svg>";
                    }else{
                        award.style.height = "50px";
                        discover.innerHTML = "<p>LIRE LA SUITE</p><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><path d='M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z'/></svg>";
                    }
                });
            });

}   

//fonction appelé pour afficher les listes d'ouverture selon le span cliqué
function toggleFilter(span){

    let ouverture_desc = document.querySelector(".ouverture-desc");

    let categorie_clients = document.querySelector(".categorie-clients");
    let nameSpan = span.innerText;
    const awards = document.querySelector(".awards");

    categorie_clients.innerText = nameSpan;
    
    while(awards.firstChild){
        console.log("ICI : "+ awards.firstChild);
        awards.removeChild(awards.firstChild);
    }

    selectOuverture(nameSpan);
    ouverture_desc.style.display ="none";
    var filterlist = span.nextElementSibling;
    if(filterlist.style.display === 'none'){
        filterlist.style.display = "flex";
        span.classList.add("up"); // Retirer la classe "up"
    }else{
        filterlist.style.display = "none";
        span.classList.remove("up"); // Retirer la classe "up"
        
    }
}


document.addEventListener("DOMContentLoaded", function() {

    // selection des variables
    const awards = document.querySelector(".awards");
    var listbys = document.querySelectorAll(".list-by");
    var selector = document.querySelector(".selector");
    var filterlists = document.querySelectorAll(".filter-lists");
    let categorie_clients = document.querySelector(".categorie-clients");
    let ouverture_desc = document.querySelector(".ouverture-desc");
    
    pushOuverture();
    

    /*
        quand selector est cliqué toggle l'affichage des listes des ouvertures par types 
        s'affichent et les principes generaux est aussi toggle
   */

    selector.addEventListener("click",function(){
        listbys.forEach(listby =>{
            if(listby.style.visibility == "hidden"){
                listby.style.visibility = "visible";
                listby.style.opacity = 1;
                selector.classList.add("up");
            }else{
                categorie_clients.innerText = "Principes généraux d’ouvertures"
                while(awards.firstChild){
                    awards.removeChild(awards.firstChild);
                }
                selector.classList.remove("up"); // Retirer la classe "up"

                listby.style.visibility = "hidden";
                ouverture_desc.style.display ="block";

                listby.style.opacity = 0;
                filterlists.forEach(filterlist => {
                    filterlist.style.display = "none";
                });

            }
        })
    });
    
    
    //event listener pour afficher les ouvertures
    listbys.forEach(function(element){
        element.addEventListener("click",function(){
            toggleFilter(this);
        });
    });

    

});


